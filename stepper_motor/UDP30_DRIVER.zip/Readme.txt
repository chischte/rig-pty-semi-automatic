UDP30_DRV_2_08_24  Contains UDP30 driver for Windows XP and Windows Vista

UDP30_DRV_2_12_24  Contains UDP30 driver for Windows 7, 8, 8.1 and Windows 10

UDP30_DRV_2_12_28  Contains UDP30 driver for Windows 7, 8, 8.1 and Windows 10 for UDP with SN > 17350000

Please note that for Windows 8 and Windows 10 is necessary to disable the driver signature enforcement to install UDP driver.  
The procedure is described in the �Disable Driver Signature Enforcement in the Windows ANEN.pdf� document.

If you have problems with the driver installation try to clean up the system following these steps:
- Disconnect any UDP device from the PC.
- Run CDMuninstallerGUI.exe inside \UDP30_DRV_Uninstaller folder.
- Fill �Vendor ID� field with �0403� and �Product ID� with �D069� (type exactly as written because the fields are case sensitive).
- Press �Add� button and then �Remove Devices� button.
- Restart Windows.
- Reconnect the UDP device and reinstall the proper operating system driver.


