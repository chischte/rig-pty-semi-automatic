To use the clean up utility follow these steps:

- Disconnect any UDP device from the PC.
- Run CDMuninstallerGUI.exe.
- Fill �Vendor ID� field with �0403� and �Product ID� with �D069� (type exactly as written because the fields are case sensitive).
- Press �Add� button and then �Remove Devices� button.
- Restart Windows.

